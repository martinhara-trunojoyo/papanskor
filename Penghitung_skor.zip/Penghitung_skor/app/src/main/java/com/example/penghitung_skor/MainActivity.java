package com.example.penghitung_skor;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView score_tim1;
    private int skorTim1;
    private TextView score_tim2;
    private int skorTim2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Inisialisasi TextView dan skor awal
        score_tim1 = findViewById(R.id.score_tim1);
        score_tim2 = findViewById(R.id.score_tim2); // tambahkan inisialisasi untuk score_tim2
        skorTim1 = 0; // Misalnya, Anda bisa mengatur skor awal di sini
        skorTim2 = 0; // tambahkan inisialisasi untuk skorTim2
        updateSkorTim1(); // Perbarui tampilan skor awal
        updateSkorTim2(); // tambahkan pembaruan untuk tampilan skor tim kedua
    }
    public void kurang(View view) {
        // Kurangi skor jika masih di atas 0
        findViewById(R.id.decreaseTeam1).setEnabled(true);
        if (skorTim1 > 0) {
            skorTim1--;
            updateSkorTim1();
            findViewById(R.id.decreaseTeam1).setEnabled(true);

        } else {
            // Matikan tombol jika skor sudah mencapai 0
            findViewById(R.id.decreaseTeam1).setEnabled(true);
        }
    }
    public void tambah(View view) {
        // Menambah skor
        skorTim1++;
        updateSkorTim1(); // Perbarui tampilan skor
    }
    public void kurang2(View view) {
        // Kurangi skor jika masih di atas 0
        if (skorTim2 > 0) {
            skorTim2--;
            updateSkorTim2();
            findViewById(R.id.decreaseTeam2).setEnabled(true);// Perbarui tampilan skor
        } else if (skorTim2 < 0) {
            // Matikan tombol jika skor sudah mencapai 0
            findViewById(R.id.decreaseTeam2).setEnabled(false);
        }
    }
    public void tambah2(View view) {
        // Menambah skor
        skorTim2++;
        updateSkorTim2(); // Perbarui tampilan skor
    }
    private void updateSkorTim1() {
        // Perbarui tampilan skor di TextView
        score_tim1.setText(String.valueOf(skorTim1));
    }
    private void updateSkorTim2() {
        // Perbarui tampilan skor di TextView untuk tim kedua
        score_tim2.setText(String.valueOf(skorTim2));
    }
}
